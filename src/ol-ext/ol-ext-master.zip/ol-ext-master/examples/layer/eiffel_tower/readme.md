Eiffel Tower by Meshick
https://sketchfab.com/3d-models/eiffel-tower-a46d5d536f874eb8acd104e2df26e323