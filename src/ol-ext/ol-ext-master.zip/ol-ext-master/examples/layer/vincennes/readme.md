Donjon Château de Vincennes by cathy.tritschler
https://3dwarehouse.sketchup.com/model/cf99310468ca30947a3dbac65b7f3618/Donjon-Ch%C3%A2teau-de-Vincennes