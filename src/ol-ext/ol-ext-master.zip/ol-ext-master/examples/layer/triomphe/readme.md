Arc de triomphe paris place de l'etoile by Julien P.
https://3dwarehouse.sketchup.com/model/253eb71daff0525047f05f2d6f0f91e5/Arc-de-triomphe-paris-place-de-latoile